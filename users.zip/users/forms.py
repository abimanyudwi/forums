from django.contrib.auth.forms import UserCreationForm, AuthenticationForm
from .models import User, Translator, Verifikator
from main.models import Verifikator as Verif
from django import forms
from main.models import Author, Administrator
from django.contrib.admin.decorators import display
from django.template.loader import get_template


class NewUserForm(UserCreationForm):
    email = forms.EmailField(
        required=True,
        widget=forms.EmailInput(
            attrs={
                "class": "form-control mx-auto",
                "style": "text-align:center;",
                "placeholder": "Surel",
            }
        ),
    )
    username = forms.CharField(
        required=True,
        widget=forms.TextInput(
            attrs={
                "class": "form-control mx-auto",
                "style": "text-align:center;",
                "placeholder": "Nama Pengguna",
            }
        ),
    )
    password1 = forms.CharField(
        required=True,
        widget=forms.PasswordInput(
            attrs={
                "class": "form-control mx-auto",
                "style": "text-align:center;",
                "placeholder": "Kata Sandi",
            }
        ),
    )
    password2 = forms.CharField(
        required=True,
        widget=forms.PasswordInput(
            attrs={
                "class": "form-control mx-auto",
                "style": "text-align:center;",
                "placeholder": "Konfirmasi Kata Sandi",
            }
        ),
    )

    class Meta:
        model = Translator
        fields = ("username", "email", "password1", "password2")

    def save(self, commit=True):
        user = super(NewUserForm, self).save(commit=False)
        user.email = self.cleaned_data["email"]
        if commit:
            user.save()
        return user


class NewVerifikatorForm(UserCreationForm):
    username = forms.CharField(
        required=True,
        widget=forms.TextInput(
            attrs={
                "class": "form-control mx-auto",
                "style": "text-align:center;",
                "placeholder": "Nama Pengguna",
            }
        ),
    )
    password1 = forms.CharField(
        required=True,
        widget=forms.PasswordInput(
            attrs={
                "class": "form-control mx-auto",
                "style": "text-align:center;",
                "placeholder": "Kata Sandi",
            }
        ),
    )
    password2 = forms.CharField(
        required=True,
        widget=forms.PasswordInput(
            attrs={
                "class": "form-control mx-auto",
                "style": "text-align:center;",
                "placeholder": "Konfirmasi Kata Sandi",
            }
        ),
    )

    class Meta:
        model = Verifikator
        fields = ("username", "email", "password1", "password2", "is_active")

    def save(self, commit=True):
        user = super(NewVerifikatorForm, self).save(commit=False)
        # user.email = self.instance.email
        if commit:
            user.save()
        return user


class AddVerifikatorForm(UserCreationForm):
    username = forms.CharField(
        required=True,
        widget=forms.TextInput(
            attrs={
                "class": "form-control mx-auto",
                "style": "text-align:center;",
                "placeholder": "Nama Pengguna",
            }
        ),
    )
    email = forms.CharField(
        required=True,
        widget=forms.EmailInput(
            attrs={
                "class": "form-control mx-auto",
                "style": "text-align:center;",
                "placeholder": "Surel",
            }
        ),
    )
    password1 = forms.CharField(
        required=True,
        widget=forms.PasswordInput(
            attrs={
                "class": "form-control mx-auto",
                "style": "text-align:center;",
                "placeholder": "Kata Sandi",
            }
        ),
    )
    password2 = forms.CharField(
        required=True,
        widget=forms.PasswordInput(
            attrs={
                "class": "form-control mx-auto",
                "style": "text-align:center;",
                "placeholder": "Konfirmasi Kata Sandi",
            }
        ),
    )

    class Meta:
        model = Verifikator
        fields = ("username", "email", "password1", "password2")

    def save(self, commit=True):
        user = super(AddVerifikatorForm, self).save(commit=False)
        # user.email = self.instance.email
        if commit:
            user.save()
        return user


class LoginForm(AuthenticationForm):
    username = forms.CharField(
        required=True,
        widget=forms.TextInput(
            attrs={
                "class": "form-control mx-auto",
                "style": "text-align:center;",
                "placeholder": "Nama Pengguna",
            }
        ),
    )
    password = forms.CharField(
        required=True,
        widget=forms.PasswordInput(
            attrs={
                "class": "form-control mx-auto",
                "style": "text-align:center;",
                "placeholder": "Kata Sandi",
            }
        ),
    )

    class Meta:
        # model = Verifikator
        fields = ("username", "password")


class UpdateAuthorForm(forms.ModelForm):
    fullname = forms.CharField(
        required=True,
        widget=forms.TextInput(
            attrs={
                "class": "form-control mx-auto",
                "style": "text-align:center;",
                "placeholder": "Nama Lengkap",
            }
        ),
    )
    profile_pic = forms.ImageField(
        required=True,
        widget=forms.FileInput(
            attrs={"class": "form-control mx-auto", "style": "text-align:center;"}
        ),
    )

    # if request.user.role ==

    class Meta:
        model = Author
        fields = ("fullname", "profile_pic")


class UpdateVerifForm(forms.ModelForm):
    fullname = forms.CharField(
        required=True,
        widget=forms.TextInput(
            attrs={
                "class": "form-control mx-auto",
                "style": "text-align:center;",
                "placeholder": "Nama Lengkap",
            }
        ),
    )
    profile_pic = forms.ImageField(
        required=True,
        widget=forms.FileInput(
            attrs={"class": "form-control mx-auto", "style": "text-align:center;"}
        ),
    )

    # if request.user.role ==

    class Meta:
        model = Verif
        fields = ("fullname", "profile_pic")


class UpdateAdminForm(forms.ModelForm):
    fullname = forms.CharField(
        required=True,
        widget=forms.TextInput(
            attrs={
                "class": "form-control mx-auto",
                "style": "text-align:center;",
                "placeholder": "Nama Lengkap",
            }
        ),
    )
    profile_pic = forms.ImageField(
        required=True,
        widget=forms.FileInput(
            attrs={"class": "form-control mx-auto", "style": "text-align:center;"}
        ),
    )

    # if request.user.role ==

    class Meta:
        model = Administrator
        fields = ("fullname", "profile_pic")
    
    
